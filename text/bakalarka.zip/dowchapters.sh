#! /usr/bin/env bash

if [[ $1 == "ok" ]]; then
    scp xpeska05@eva.fit.vutbr.cz:/homes/eva/xp/xpeska05/Bakalarka/projekt-01-kapitoly-chapters.tex .
fi
