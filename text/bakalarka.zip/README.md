# Bakalarska prace - textova cast

## Jak psat bakalarskou praci
- www.herout.net/tao-diplomky/
- www.mitvsehotovo.cz

## LaTex
- https://en.wikibooks.org/wiki/LaTeX/Footnotes_and_Margin_Notes
- http://www.cs.vsb.cz/benes/vyuka/latex/
- https://www.latex-tutorial.com/symbols/math-symbols/
- https://www.overleaf.com/learn/latex/Line_breaks_and_blank_spaces
- http://www.fit.vutbr.cz/~martinek/latex/control.html
- https://latex.wikia.org/wiki/Matrix_environments

### Symbols
- http://www.rpi.edu/dept/arc/training/latex/LaTeX_symbols.pdf
