Rekonstuovane nahravky byly separovany pomoci site nactene z checkpointu.
Checkpoint byl ulozeny model site trenovany po 60 epoch a sit mela rozmery X8, R4.
Checkpoint nebyl prilozen kvuli jeho velikosti, ale parametry teto site lze precist v prilozenem souboru model_X8_R4/training.log
